let cart = [];
let total = 0;

fetch("/foods")
.then(res => res.json())
.then(data => {

const menu = document.getElementById("menu");

data.forEach(food => {

const div = document.createElement("div");
div.className="food";

div.innerHTML =
"<b>"+food.name+"</b><br>"+
"₹"+food.price+"<br>"+
"<button onclick='addToCart(\""+food.name+"\","+food.price+")'>Add to Cart</button>";

menu.appendChild(div);

});

});

function addToCart(name,price){

cart.push({name,price});
total += price;

const li = document.createElement("li");
li.innerText = name + " - ₹" + price;

document.getElementById("cart").appendChild(li);
document.getElementById("total").innerText = total;

}

function placeOrder(){

if(cart.length === 0){
alert("Cart is empty");
return;
}

fetch("/orders",{
method:"POST",
headers:{"Content-Type":"application/json"},
body:JSON.stringify({items:cart,total})
})
.then(res=>res.json())
.then(()=>{
alert("Order placed!");

cart=[];
total=0;

document.getElementById("cart").innerHTML="";
document.getElementById("total").innerText="0";
});

}