const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const foodRoutes = require("./routes/foodRoutes");
const orderRoutes = require("./routes/orderRoutes");

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static("public"));

mongoose.connect("mongodb://127.0.0.1:27017/foodDB")
.then(()=>console.log("MongoDB connected"))
.catch(err=>console.log(err));

app.use("/foods", foodRoutes);
app.use("/orders", orderRoutes);

app.listen(5000,()=>{
console.log("Server running on port 5000");
});